package com.service.assets.service;

import com.service.assets.model.Alert;
import com.service.assets.model.Asset;
import com.service.assets.model.Incident;
import com.service.assets.model.PerformanceMetric;
import com.service.assets.repo.AlertRepository;
import com.service.assets.repo.AssetRepository;
import com.service.assets.repo.IncidentRepository;
import com.service.assets.repo.PerformanceMetricRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

@Service
public class InfrastructureMonitoringService {

    private final AssetRepository assetRepository;
    private final PerformanceMetricRepository metricRepository;
    private final AlertRepository alertRepository;
    private final IncidentRepository incidentRepository;
    private final Random random = new Random();

    public InfrastructureMonitoringService(AssetRepository assetRepository,
                                           PerformanceMetricRepository metricRepository,
                                           AlertRepository alertRepository,
                                           IncidentRepository incidentRepository) {
        this.assetRepository = assetRepository;
        this.metricRepository = metricRepository;
        this.alertRepository = alertRepository;
        this.incidentRepository = incidentRepository;
    }

    @Scheduled(fixedRate = 2000)
    @Transactional
    public void scrapeInfrastructureTelemetry() {
        List<Asset> assets = assetRepository.findAll();

        for (Asset asset : assets) {
            float cpu = random.nextFloat() * 100;
            float memory = random.nextFloat() * 100;
            float disk = random.nextFloat() * 100;
            float network = random.nextFloat() * 100;
            Optional<PerformanceMetric> existingMetric =
                    metricRepository.findByAssetId(asset.getAssetId());

            PerformanceMetric metric;

            if(existingMetric.isPresent()){

                metric = existingMetric.get();

                metric.setCpuUsage(cpu);
                metric.setMemoryUsage(memory);
                metric.setDiskUsage(disk);
                metric.setNetworkUsage(network);
                metric.setTimestamp(OffsetDateTime.now());

            }else{

                metric = new PerformanceMetric(
                        asset.getAssetId(),
                        cpu,
                        memory,
                        disk,
                        network);

            }

            metricRepository.save(metric);
            evaluateRulesAndHealth(asset, metric);
        }
    }
    private void evaluateRulesAndHealth(Asset asset, PerformanceMetric metric) {
        Asset.HealthStatus targetStatus = Asset.HealthStatus.HEALTHY;

        targetStatus = checkMetricThreshold(asset, "CPU", metric.getCpuUsage(), targetStatus);
        targetStatus = checkMetricThreshold(asset, "Memory", metric.getMemoryUsage(), targetStatus);
        targetStatus = checkMetricThreshold(asset, "Disk", metric.getDiskUsage(), targetStatus);

        if (asset.getStatus() != targetStatus) {
            asset.setStatus(targetStatus);
            asset.setUpdatedAt(OffsetDateTime.now());
            assetRepository.save(asset);

            if (targetStatus == Asset.HealthStatus.CRITICAL) {
                triggerIncidentFromFailure(asset, metric);
            }
        }
    }
    private void triggerIncidentFromFailure(Asset asset, PerformanceMetric metric) {
        Incident incident = new Incident();
        incident.setIncidentTicket("INC-2026-" + (1000 + random.nextInt(9000)));
        incident.setSeverity(Incident.IncidentSeverity.CRITICAL);
        incident.setStatus(Incident.IncidentStatus.OPEN);
        incident.setType("Infrastructure Resource Exhaustion");
        incident.setSourceIp("INTERNAL-VPC");
        incident.setImpactSummary(String.format("Critical load on %s | CPU: %.1f%% | Mem: %.1f%%",
                asset.getName(), metric.getCpuUsage(), metric.getMemoryUsage()));
        incident.setAssignedTeam("Cloud Operations Team");
        incident.setSlaHours(1);
        incident.setEtaMinutes(30);

        incidentRepository.save(incident);
    }
    private Asset.HealthStatus checkMetricThreshold(Asset asset, String metricName, float value, Asset.HealthStatus currentEvaluatedStatus) {
        Asset.HealthStatus nextStatus = currentEvaluatedStatus;

        if (value >= 90.0f) {
            nextStatus = Asset.HealthStatus.CRITICAL;
            triggerAlertIfNew(asset.getAssetId(), metricName, value, Alert.AlertSeverity.CRITICAL);
        } else if (value >= 75.0f) {
            if (nextStatus != Asset.HealthStatus.CRITICAL) {
                nextStatus = Asset.HealthStatus.WARNING;
            }
            triggerAlertIfNew(asset.getAssetId(), metricName, value, Alert.AlertSeverity.HIGH);
        } else {
            resolveAlertsIfAny(asset.getAssetId(), metricName);
        }
        return nextStatus;
    }
    private void triggerAlertIfNew(UUID assetId, String metricName, float value, Alert.AlertSeverity severity) {
        List<Alert> activeAlerts = alertRepository.findByAssetIdAndResolvedFalse(assetId);
        boolean alreadyFired = activeAlerts.stream().anyMatch(a -> a.getMetricName().equalsIgnoreCase(metricName));

        if (!alreadyFired) {
            maintainAlertLimit();
            Alert alert = new Alert(assetId, metricName, value, severity);
            alertRepository.save(alert);
        }
    }
    private void resolveAlertsIfAny(UUID assetId, String metricName) {
        List<Alert> activeAlerts = alertRepository.findByAssetIdAndResolvedFalse(assetId);
        activeAlerts.stream()
                .filter(a -> a.getMetricName().equalsIgnoreCase(metricName))
                .forEach(a -> {
                    a.setResolved(true);
                    alertRepository.save(a);
                });
    }
    private void maintainAlertLimit() {
        long totalAlerts = alertRepository.count();
        if (totalAlerts >= 70) {
            List<Alert> alerts = alertRepository.findAllByOrderByCreatedAtAsc();
            alertRepository.delete(alerts.get(0));
        }
    }
}