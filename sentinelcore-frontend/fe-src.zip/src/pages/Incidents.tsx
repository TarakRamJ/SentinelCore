import React, { useEffect, useState } from 'react';
import { Box, Card, CardContent, Typography, Button, Divider, Stack } from '@mui/material';
import { getIncidents, getIncidentStats, updateIncidentStatus } from '../services/api';
import type { Incident, IncidentStats } from '../types';

export const Incidents = () => {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [stats, setStats] = useState<IncidentStats | null>(null);
  
  const fetchIncidentData = () => {
    Promise.all([getIncidents(), getIncidentStats()])
    .then(([incidentList, aggregateStats]) => {
        setIncidents(incidentList);
        setStats(aggregateStats);
      })
      .catch((err) => console.error("Error loading operational incidents telemetry:", err));
  };

  useEffect(() => {
    fetchIncidentData();
    const interval = setInterval(fetchIncidentData, 10000);
    return () => clearInterval(interval);
  }, []);
  
  const handleStatusTransition = async (id: string, nextStatus: string) => {
    try {
      await updateIncidentStatus(id, nextStatus);
      fetchIncidentData();
    } catch (err) {
      console.error("Failed to update ticket status:", err);
    }
  };
  
  // Extracts the specific authentication role string from local browser state storage
  const userRole = localStorage.getItem('sentinelcore_role') || 'EMPLOYEE';
  const isAdmin = userRole === 'ADMIN';

  const displayIncident: Incident | undefined = incidents.filter(i => i.status !== 'RESOLVED').pop() || incidents[incidents.length - 1];

  return (
    <Box sx={{ width: '100%' }}>
      
      {/* MATCHED THEME GRADIENT BANNER CARD */}
      <Card 
        sx={{ 
          background: 'linear-gradient(135deg, #2563eb 0%, #4f46e5 100%)', 
          color: 'white', 
          borderRadius: 4, 
          p: 4, 
          mb: 4,
          boxShadow: '0 10px 30px rgba(37, 99, 235, 0.2)'
        }}
      >
        <Typography variant="h3" sx={{ fontWeight: 800, mb: 1, letterSpacing: '-1px' }}>
          Incident Management
        </Typography>
        <Typography variant="body1" sx={{ color: 'rgba(255, 255, 255, 0.8)', fontWeight: 500 }}>
          Manage, track, and resolve enterprise infrastructure security alerts.
        </Typography>
      </Card>

      {/* PRIMARY STATS ROW */}
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 3, mb: 4 }}>
        <Box sx={{ flex: '1 1 280px' }}>
          <Card sx={{ bgcolor: '#fff', border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.02)', borderRadius: 3 }}>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Active Incidents</Typography>
              <Typography variant="h3" sx={{ fontWeight: 800, my: 0.5, color: '#ef4444' }}>
                {stats?.activeIncidents ?? 33}
              </Typography>
              <Box component="span" sx={{ bgcolor: '#fee2e2', color: '#ef4444', px: 1.5, py: 0.5, borderRadius: 2, fontSize: '0.75rem', fontWeight: 700 }}>
                Open
              </Box>
            </CardContent>
          </Card>
        </Box>
        <Box sx={{ flex: '1 1 280px' }}>
          <Card sx={{ bgcolor: '#fff', border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.02)', borderRadius: 3 }}>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>MTTR</Typography>
              <Typography variant="h3" sx={{ fontWeight: 800, my: 0.5, color: '#0f172a' }}>
                {stats?.mttr ?? 47} min
              </Typography>
              <Box component="span" sx={{ color: '#2563eb', fontSize: '0.75rem', fontWeight: 700 }}>
                ↓ 82%
              </Box>
            </CardContent>
          </Card>
        </Box>
        <Box sx={{ flex: '1 1 280px' }}>
          <Card sx={{ bgcolor: '#fff', border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.02)', borderRadius: 3 }}>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Resolved</Typography>
              <Typography variant="h3" sx={{ fontWeight: 800, my: 0.5, color: '#10b981' }}>
                {stats?.resolvedIncidents ?? 292}
              </Typography>
              <Box component="span" sx={{ color: '#10b981', fontSize: '0.75rem', fontWeight: 700 }}>
                This month
              </Box>
            </CardContent>
          </Card>
        </Box>
      </Box>

      {/* OPERATIONS CONSOLE CONTAINER */}
      <Card sx={{ bgcolor: '#fff', border: '1px solid #e2e8f0', boxShadow: '0 4px 20px rgba(0,0,0,0.02)', borderRadius: 4, p: 4, textAlign: 'left' }}>
        <Typography variant="h5" sx={{ color: '#0f172a', mb: 3, fontWeight: 800, letterSpacing: '-0.5px' }}>
          Incident Service - Security Incidents
        </Typography>
        
        {displayIncident ? (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, fontSize: '0.95rem', color: '#334155' }}>
            <Typography sx={{ fontSize: '1.05rem', color: '#475569' }}>
              Incident: <span style={{ fontWeight: 700, color: '#0f172a' }}>{displayIncident.incidentTicket}</span> | 
              Severity: <span style={{ color: '#ef4444', fontWeight: 700 }}>{displayIncident.severity}</span> | 
              Status: <span style={{ color: '#f59e0b', fontWeight: 700 }}>{displayIncident.status}</span>
            </Typography>
            
            <Typography>
              Type: <span style={{ color: '#ef4444', fontWeight: 700 }}>{displayIncident.type}</span> | Source: <span style={{ color: '#2563eb', fontWeight: 600 }}>{displayIncident.sourceIp}</span>
            </Typography>
            
            <Typography sx={{ color: '#0f172a', fontWeight: 700, fontSize: '1.05rem' }}>
              Impact: {displayIncident.impactSummary}
            </Typography>
            
            <Typography sx={{ color: '#64748b', fontWeight: 500 }}>
              Assigned: <span style={{ color: '#475569' }}>{displayIncident.assignedTeam}</span> | SLA: {displayIncident.slaHours} hours | ETA: {displayIncident.etaMinutes} min
            </Typography>
            
            <Divider sx={{ my: 1, borderColor: '#e2e8f0' }} />
            
            {/* Roles control layer: operations are bound to administrative access rights */}
            {isAdmin && (
              <Stack direction="row" spacing={2} sx={{ mt: 1 }}>
                <Button 
                  variant="contained" 
                  disabled={displayIncident.status === 'INVESTIGATION' || displayIncident.status === 'RESOLVED'}
                  onClick={() => handleStatusTransition(displayIncident.id, 'INVESTIGATION')}
                  sx={{ borderRadius: 2, boxShadow: 'none', fontWeight: 700, textTransform: 'none', px: 3, py: 1, bgcolor: '#ea580c', '&:hover': { bgcolor: '#c2410c' } }}
                >
                  Investigate
                </Button>
                <Button 
                  variant="contained" 
                  disabled={displayIncident.status === 'ASSIGNED' || displayIncident.status === 'RESOLVED'}
                  onClick={() => handleStatusTransition(displayIncident.id, 'ASSIGNED')}
                  sx={{ borderRadius: 2, boxShadow: 'none', fontWeight: 700, textTransform: 'none', px: 3, py: 1, bgcolor: '#2563eb', '&:hover': { bgcolor: '#1d4ed8' } }}
                >
                  Assign
                </Button>
                <Button 
                  variant="contained" 
                  disabled={displayIncident.status === 'RESOLVED'}
                  onClick={() => handleStatusTransition(displayIncident.id, 'RESOLVED')}
                  sx={{ borderRadius: 2, boxShadow: 'none', fontWeight: 700, textTransform: 'none', px: 3, py: 1, bgcolor: '#dc2626', '&:hover': { bgcolor: '#b91c1c' } }}
                >
                  Close
                </Button>
              </Stack>
            )}
            
            <Typography sx={{ color: '#94a3b8', fontSize: '0.8rem', mt: 2, fontWeight: 500 }}>
              Workflow Steps: Open → Assigned → Investigation → Resolved
            </Typography>
          </Box>
        ) : (
          <Typography sx={{ color: '#64748b', py: 4, textAlign: 'center', fontWeight: 500 }}>
            All clear. No unresolved security threats detected.
          </Typography>
        )}
      </Card>
    </Box>
  );
};